﻿using Xamarin.Forms;

namespace eShopOnContainers.Core.Views
{
    public partial class SettingsView : ContentPage
    {
        public SettingsView()
        {
            InitializeComponent();
        }
    }
}
