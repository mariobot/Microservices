﻿using SlideOverKit;

namespace eShopOnContainers.Core.Views
{
    public partial class FiltersView : SlideMenuView
    {
        public FiltersView()
        {
            InitializeComponent();
        }
    }
}
