﻿using Xamarin.Forms;

namespace eShopOnContainers.Core.Views
{
    public partial class BasketView : ContentPage
    {
        public BasketView()
        {
            InitializeComponent();
        }
    }
}