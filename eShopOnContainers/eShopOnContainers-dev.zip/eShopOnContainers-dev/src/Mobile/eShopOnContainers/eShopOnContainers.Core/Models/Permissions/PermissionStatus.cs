﻿namespace eShopOnContainers.Core.Models.Permissions
{
    public enum PermissionStatus
    {
        Denied,
        Disabled,
        Granted,
        Restricted,
        Unknown
    }
}
